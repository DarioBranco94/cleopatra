<!DOCTYPE html>
<html>
<!--
Esempio di istanziazione di Mirador con apertura diretta su di un'immagine.
Si tratta di un manoscritto di e-codices, e il dato relativo a canvasID è preso dal suo
manifest.json; le altre opzioni di windowObjects sono in:
https://github.com/IIIF/mirador/wiki/Complete-Configuration-API#loaded-objects

-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Mirador Viewer</title>
    <style type="text/css">
     #viewer {  width: 100%; height: 100%; }
    </style>
    
    <script src="mirador3/mirador.min.js"></script>
    
  
    
    <link rel="stylesheet" type="text/css" href="mirador3/manifestButton.css" />
    
    <!--  Bot Libs-->

    <script type='text/javascript' src='echobot2.js'></script>

	<link rel="stylesheet" type="text/css" media="screen" href="package/dist/converse.min.css">
	<script src="package/dist/converse.js"></script>
	<script  type="module" src='strophe.umd.js'></script>



</head>

<body>

    <div id="viewer"/>
	<script>


		var aut = converse.initialize({
			bosh_service_url: 'https://conversejs.org/http-bind/', // Please use this connection manager only for testing purposes
			show_controlbox_by_default: true,
			jid: 'chat.cleopatra-agents.cloud',
			authentication: 'anonymous',
			auto_login: true,
			allow_logout: false,
			auto_join_rooms: [{'jid': 'chat@muc.chat.cleopatra-agents.cloud'}]
		});
		console.log('TEEEEEEST');
	</script>

	  <script type="text/javascript">

	var miradorInstance = Mirador.viewer({
       id: 'viewer',
       language: 'it',
      selectedTheme: 'dark',
      
      window: {
		  panels: {
			layers: true
		 },
		  defaultView:'single',
				views: [
						{ key: 'single'},
						{ key: 'book' },
						{ key: 'scroll'},
						{ key: 'gallery' }
						]
				
			},
	  windows: [{
		 id: 'main_window',
      //   manifestId: 'http://143.225.20.99/alba/msprova/manifest.json',
      manifestId: 'msprova/manifest.json',
      //   canvasId: 'http://www.dante.unina.it/iiif/ms_jp2/CNMD0000249997/CNMD0000249997_0001.jp1',
        thumbnailNavigationPosition: 'far-bottom',
       }],
       manifestButton: {
		iconClass: 'fa-file' // Define the icon class of the button
		},

     });

    </script>

</body>
    
<script>    
    window.document.body.insertAdjacentHTML( 'afterbegin', '<div id="conversejs" style="display:block;box-sizing: border-box;z-index:1031;bottom:5px;margin:0;right:10px;left:0;height:3em;position:fixed;padding-left: env(safe-area-inset-left);padding-right:env(safe-area-inset-right);"><div style="z-index: 1031;position: fixed;top: 10em;right: 260px;display: flex;flex-wrap: wrap;"><div  class="flyout box-flyout" style="width:250px;display: flex;flex-direction: column; justify-content: space-between;box-shadow: 1px 3px 5px 3px rgb(0 0 0 / 40%);z-index: 2;overflow: hidden; border-radius: 0;position:absolute;flex-direction: column;"><canvas id="cv" style="border: 1px solid;" width="250" height="250" ></canvas></div></div></div>' );

</script>


</html>
