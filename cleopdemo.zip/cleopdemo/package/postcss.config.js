/* global module */
module.exports = {
    plugins: [
        require('autoprefixer'),
        require('postcss-clean')
    ]
}
