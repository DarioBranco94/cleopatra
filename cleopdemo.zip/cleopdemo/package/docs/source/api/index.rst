.. raw:: html

    <div id="banner"><a href="https://github.com/jcbrand/converse.js/blob/master/docs/source/theming.rst">Edit me on GitHub</a></div>

============================================
The API documentation (generated with JSDoc)
============================================

This document is a stub. It shouldn't show at all, instead it's a hack in order
to link to the JSDoc output.

See https://stackoverflow.com/questions/27979803/external-relative-link-in-sphinx-toctree-directive
