/*global global*/

import './bosh.js';
import './websocket.js';
import './worker-websocket.js';
import * as strophe from './core.js';

global.$build = strophe.default.$build;
global.$iq = strophe.default.$iq;
global.$msg = strophe.default.$msg;
global.$pres = strophe.default.$pres;
global.Strophe = strophe.default.Strophe;

export { Strophe, $build, $iq, $msg, $pres } from './core.js';

export const { b64_sha1 } = strophe.SHA1;
